module PhotosHelper
end
